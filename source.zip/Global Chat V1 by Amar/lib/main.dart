
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.android,
  );
  runApp(const GlobalChatApp());
}

final auth = FirebaseAuth.instance;
final db = FirebaseDatabase.instance;

class GlobalChatApp extends StatelessWidget {
  const GlobalChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'GLOBAL CHAT',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090914),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00E5FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: auth.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.data != null) return const ChatPage();
        return const LoginPage();
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();

  bool register = false;
  bool loading = false;

  void message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(value)),
    );
  }

  Future<void> submit() async {
    if (email.text.trim().isEmpty ||
        password.text.length < 6) {
      message('Isi email dan password minimal 6 karakter.');
      return;
    }

    if (register && name.text.trim().isEmpty) {
      message('Isi username terlebih dahulu.');
      return;
    }

    setState(() => loading = true);

    try {
      if (register) {
        final result = await auth.createUserWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        await result.user?.updateDisplayName(name.text.trim());
      } else {
        await auth.signInWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
      }
    } on FirebaseAuthException catch (e) {
      message(e.message ?? e.code);
    } catch (e) {
      message('Terjadi kesalahan: $e');
    }

    if (mounted) setState(() => loading = false);
  }

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Icon(
                Icons.forum_rounded,
                size: 75,
                color: Color(0xFF00E5FF),
              ),
              const SizedBox(height: 16),
              const Text(
                'GLOBAL CHAT',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                  color: Color(0xFF00E5FF),
                ),
              ),
              const SizedBox(height: 8),
              const Text('Connect with everyone.'),
              const SizedBox(height: 35),

              if (register) ...[
                TextField(
                  controller: name,
                  decoration: const InputDecoration(
                    labelText: 'Username',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 14),
              ],

              TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 14),

              TextField(
                controller: password,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 22),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: loading ? null : submit,
                  child: loading
                      ? const CircularProgressIndicator()
                      : Text(register ? 'CREATE ACCOUNT' : 'LOGIN'),
                ),
              ),

              TextButton(
                onPressed: () {
                  setState(() => register = !register);
                },
                child: Text(
                  register
                      ? 'Sudah punya akun? Login'
                      : 'Belum punya akun? Daftar',
                ),
              ),

              const SizedBox(height: 25),
              const Text(
                'Amar ganteng Dev',
                style: TextStyle(color: Colors.white38),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();

  User get user => auth.currentUser!;

  DatabaseReference get messagesRef => db.ref('messages');

  DatabaseReference get roleRef => db.ref('roles/${user.uid}/role');

  Future<void> send() async {
    final text = controller.text.trim();

    if (text.isEmpty) return;
    if (text.length > 1000) {
      showMessage('Pesan maksimal 1000 karakter.');
      return;
    }

    try {
      await messagesRef.push().set({
        'senderUid': user.uid,
        'senderName': user.displayName ?? 'Member',
        'text': text,
        'createdAt': ServerValue.timestamp,
      });
      controller.clear();
    } catch (e) {
      showMessage('Pesan gagal dikirim. Periksa koneksi dan Rules.');
    }
  }

  void showMessage(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(value)),
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'GLOBAL CHAT',
          style: TextStyle(
            color: Color(0xFF00E5FF),
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          StreamBuilder<DatabaseEvent>(
            stream: roleRef.onValue,
            builder: (context, snapshot) {
              final role = snapshot.data?.snapshot.value == 'Dev'
                  ? 'Amar Dev'
                  : 'Member';

              return Center(
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: role == 'Amar Dev'
                        ? const Color(0xFF72551A)
                        : const Color(0xFF30303A),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    role,
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => auth.signOut(),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<DatabaseEvent>(
              stream: messagesRef
                  .orderByChild('createdAt')
                  .limitToLast(100)
                  .onValue,
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                    child: Text('Gagal memuat pesan.'),
                  );
                }

                if (!snapshot.hasData ||
                    snapshot.data!.snapshot.value == null) {
                  return const Center(
                    child: Text('Belum ada pesan. Mulai ngobrol!'),
                  );
                }

                final items =
                    snapshot.data!.snapshot.children.toList();

                items.sort((a, b) {
                  final ta = a.child('createdAt').value as num? ?? 0;
                  final tb = b.child('createdAt').value as num? ?? 0;
                  return ta.compareTo(tb);
                });

                return ListView.builder(
                  padding: const EdgeInsets.all(14),
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    final sender = item.child('senderName').value
                        ?.toString() ?? 'Member';
                    final text = item.child('text').value
                        ?.toString() ?? '';
                    final mine = item.child('senderUid').value ==
                        user.uid;

                    return Align(
                      alignment: mine
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        constraints: const BoxConstraints(
                          maxWidth: 290,
                        ),
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: mine
                              ? const Color(0xFF123B50)
                              : const Color(0xFF1C1C2B),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              sender,
                              style: const TextStyle(
                                color: Color(0xFF00E5FF),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(text),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    maxLength: 1000,
                    decoration: const InputDecoration(
                      hintText: 'Tulis pesan...',
                      counterText: '',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => send(),
                  ),
                ),
                IconButton(
                  onPressed: send,
                  icon: const Icon(
                    Icons.send,
                    color: Color(0xFF00E5FF),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
