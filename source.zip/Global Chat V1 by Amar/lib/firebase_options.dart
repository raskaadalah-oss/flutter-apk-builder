
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'ISI_CURRENT_KEY_DI_SINI',
    appId: '1:213987056560:android:44ec275f283c970701d475',
    messagingSenderId: '213987056560',
    projectId: 'globalchat-45456',
    databaseURL:
        'https://globalchat-45456-default-rtdb.asia-southeast1.firebasedatabase.app',
    storageBucket: 'globalchat-45456.firebasestorage.app',
  );
}
